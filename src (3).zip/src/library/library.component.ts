import { Component } from '@angular/core';

@Component({
  selector: 'lib',
  templateUrl: './library.component.html',
  styleUrls: ['./library.component.css']
  //styleUrls: ['./app.component.css']
})
export class LibraryComponent{
  
  library:string="online";
  imgWidth:number=400;
  imgHeight:number=300;


}
