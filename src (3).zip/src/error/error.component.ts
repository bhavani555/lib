import { Component } from '@angular/core';
import { ActivatedRoute, Router } from "@angular/router";

@Component({
  selector: 'err',
  templateUrl: './error.component.html',
//styleUrls: ['./about.component.css'],
  //styleUrls: ['./app.component.css']
})
export class ErrorComponent{
      constructor(private route: ActivatedRoute, private router: Router) { };

  onBack(): void {

        this.router.navigate(['/library']);
    }

}
