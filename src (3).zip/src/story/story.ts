export interface IStory{

    id:number;
    Title:string;
    catagory:string;
    Author:string;
    bookImg:string;
    
}