
import { ActivatedRoute, Router } from '@angular/router';
import { OnInit, Component } from '@angular/core';
import { IBook } from "../book/book";

@Component({
    templateUrl: './bookDetail.component.html',
 
})
export class bookDetailComponent implements OnInit,IBook {

    pgtitle: string = "book Details";
     Title: IBook;
    constructor(private route: ActivatedRoute, private router: Router) { };

    ngOnInit() {

        let id = +this.route.snapshot.paramMap.get('id');
       // let Title = this.route.snapshot.paramMap.get('Title');
        this.pgtitle +=  `: ${id}`;
        this.Title = {
            'id': id,
            'Title': `${'Title'}`,
            'catagory': 'fiction',
            'Author': 'preetishenoy',
            'bkImage':"5"
        };

    }

    onBack(): void {

        this.router.navigate(['/book']);
    }

}

