import { Component, OnInit} from '@angular/core';
import { NgForm } from '@angular/forms';
import { User } from "./user";

@Component({
  selector: 'fr',
  templateUrl: './form.component.html',
  //styleUrls: ['./form.component.css'],
  //styleUrls: ['./app.component.css']
})
export class FormComponent implements OnInit{
  ngOnInit(): void {
    // throw new Error("Method not implemented.");
  }
 user=new User();

 constructor(){

 }

 save(userForm:NgForm){
   console.log(userForm.form);
   console.log('Saved data' + JSON.stringify(userForm.value))
 }



}
